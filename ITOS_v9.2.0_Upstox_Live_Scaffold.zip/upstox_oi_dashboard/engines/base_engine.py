from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import asdict, dataclass, field
from datetime import datetime
from typing import Any


@dataclass
class EngineResult:
    engine: str
    score: float
    vote: str
    explanation: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    captured_at: str = field(default_factory=lambda: datetime.now().astimezone().isoformat(timespec="seconds"))

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class BaseEngine(ABC):
    """Common interface for all pluggable intelligence engines."""

    name = "Base Engine"

    @abstractmethod
    def analyze(self, market_data: dict[str, Any]) -> EngineResult:
        raise NotImplementedError

    def score(self, result: EngineResult) -> float:
        return float(result.score)

    def explain(self, result: EngineResult) -> list[str]:
        return list(result.explanation)

    def vote(self, result: EngineResult) -> str:
        return str(result.vote)

    def save_history(self, result: EngineResult, store: Any, **context: Any) -> None:
        """Optional persistence hook. Engines may override this."""
        return None
