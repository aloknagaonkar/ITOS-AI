WEIGHTS={"oi":20,"oi_change":15,"pcr":10,"depth":15,"greeks":15,"volume":10,"vwap":5,"price":10}
def score(parts):
    return sum(parts.get(k,0)*v/100 for k,v in WEIGHTS.items())
