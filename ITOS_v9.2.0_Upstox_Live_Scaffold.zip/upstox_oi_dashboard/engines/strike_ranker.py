def rank(strikes):
    return sorted(strikes,key=lambda s:s.get("score",0),reverse=True)
