# Changelog

## 8.4.0

- Added two primary Streamlit tabs: Live Market Intelligence and Intelligence Explorer.
- Reorganized existing information without redesigning the v8.3 interface.
- Added a sidebar version banner.
- Updated page and application version labels to v8.4.0.
- Preserved all existing engines and business logic.

## 8.4.1

- Added modular AI Trade Opportunity decision center below Key Market Levels.
- Added trade dataclasses, Explainable AI engine, AI Trade orchestrator and reusable UI renderer.
- Preserved existing engine logic and detailed dashboard panels.
